package com.example.myapplication;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
//import com.google.firebase.firestore.EventListener;

import java.util.ArrayList;
import java.util.List;


public class VolunteerTaskListActivity extends AppCompatActivity {


    private String[] data = {"TaskA","TaskB","TaskC","TaskD","TaskE","TaskF","TaskG","TaskH","TaskI","TaskJ","TaskK","TaskL",
                             "TaskM","TaskN","TaskO","TaskP" };
    int P = 0;
    private static final String KEY_TITLE = "Title", KEY_DESCRIPTION = "Description",KEY_DATE= "Date",KEY_TIME ="Time",KEY_ADDRESS="Address";

    FirebaseFirestore Fb;

    static TaskPost CurrentTask;

    private List<TaskPost> TaskList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        //setContentView(R.layout.activity_volunteer_task_list);
        //init_Firebase();
        //TaskList  = com.example.myapplication.TasklistLoadEvent.getTaskList();
        //ReadlistData();
        initTaskList();
        initTaskList();
        setContentView(R.layout.activity_volunteer_task_list);
        TaskAdapter adapter = new TaskAdapter(VolunteerTaskListActivity.this, R.layout.task_item,TaskList);
        adapter.notifyDataSetChanged();
        ListView lv = (ListView) findViewById(R.id.Tasks_list_data);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {

                 //TaskPost task = TaskList.get(position);
                CurrentTask = TaskList.get(position);
                if (VolunteerActivity.getTaskType().equals("General")) {
                    if (!TasklistLoadEvent.isTaskAccepted(CurrentTask.getEmail())) {
                        startActivity(new Intent(VolunteerTaskListActivity.this, VolunteerTaskAcceptActivity.class));
                    } else {
                        Toast.makeText(VolunteerTaskListActivity.this, "Sorry, this task has been accepted by someone else", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(VolunteerTaskListActivity.this, VolunteerActivity.class));
                    }
                }
                else{
                    startActivity(new Intent(VolunteerTaskListActivity.this, VolunteerTaskAcceptActivity.class));
                }
            }
        });



    }

    public void init_Firebase()
    {
        Fb = FirebaseFirestore.getInstance();
    }




/*
    public void initTaskList() {
        for (int i = 0; i < 2; i++) {
            TaskPost task = new TaskPost("task1","ee","sa");
            TaskList.add(task);

            TaskPost task1 = new TaskPost("task_asd","SS","sad");
            TaskList.add(task1);

            TaskPost apple = new TaskPost("Task_apple","kk","sad");
            TaskList.add(apple);


        }
    }
*/
    public void initTaskList() {
        TaskList  = com.example.myapplication.TasklistLoadEvent.getTaskList();


   }

   public static TaskPost GetCurrentTask() {
        return CurrentTask;

    }



}